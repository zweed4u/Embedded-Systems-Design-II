First ensure you have a neg folder - these are images that are pulled from image-net that serve as background/negative images
These can be pulled via brick_negatives.py this script will also write your description file for negatives (bg.txt)

After all negative images have been pulled quickly go through the brick_neg dir and copy any "broken" images to "ugly_broken_imgs" dir
Run brick_ugs.py this will remove all broken images from our set

In this same directory ensure that you have your positive image/object image that you wish to detect

Make info and data directory for all objects you wish to detect (2 folders for each positive image)

From here run/modify and run the brick_train shell script - making note of flags and options in each call. 
I'm not going to hold your hand here. Be smart and replicate. It should be easy enough.

This shell script will generate positive images, vector files and train the cascade
