# rover

This repository is for the rover used in the Embedded Systems Design II class taught at the Rochester Institute of Technology.
[CPET 563]