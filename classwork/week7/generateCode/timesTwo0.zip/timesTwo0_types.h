/*
 * timesTwo0_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "timesTwo0".
 *
 * Model version              : 1.10
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Tue Feb 28 08:31:11 2017
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_timesTwo0_types_h_
#define RTW_HEADER_timesTwo0_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_timesTwo0_T RT_MODEL_timesTwo0_T;

#endif                                 /* RTW_HEADER_timesTwo0_types_h_ */
